
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  DollarSign, 
  Trophy, 
  Menu,
  TrendingUp,
  Award,
  Settings,
  CheckCircle2,
  X,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  Briefcase,
  ExternalLink,
  Target,
  BarChart3,
  Calculator,
  Zap
} from 'lucide-react';
import { Client, Task, AppState, Status, UserStats, Transaction, DayOfWeek, Album, Budget, Service, Invoice, Reminder } from './types';
import { INITIAL_STATE, XP_PER_TASK, XP_PER_CLIENT, XP_PER_LEVEL, XP_DAILY_BRIEFING, XP_MAIN_GOAL } from './constants';
import KanbanBoard from './components/KanbanBoard';
import FinanceDashboard from './components/FinanceDashboard';
import ClientManagement from './components/ClientManagement';
import GamificationBar from './components/GamificationBar';
import SettingsView from './components/SettingsView';
import PortfolioTab from './components/Portfolio/PortfolioTab';
import PublicPortfolioView from './components/Portfolio/PublicPortfolioView';
import BudgetBuilder from './components/Budget/BudgetBuilder';
import TaskModal from './components/Modals/TaskModal';
import PaymentModal from './components/Modals/PaymentModal';
import ProjectNoteModal from './components/Modals/ProjectNoteModal';
import BriefingModal from './components/Modals/BriefingModal';
import FocusWidget from './components/Dashboard/FocusWidget';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'kanban' | 'finance' | 'clients' | 'dashboard' | 'settings' | 'portfolio' | 'budgets'>('dashboard');
  const [isPublicView, setIsPublicView] = useState(false);
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('cybermanager_state');
    return saved ? JSON.parse(saved) : INITIAL_STATE;
  });

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [selectedClientForInvoice, setSelectedClientForInvoice] = useState<Client | null>(null);
  const [pendingPaymentTask, setPendingPaymentTask] = useState<Task | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showBriefing, setShowBriefing] = useState(false);

  // Stats Calculations
  const monthlyIncome = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    return state.transactions
      .filter(t => {
        const d = new Date(t.date);
        return t.type === 'Entrada' && t.status === 'Pago' && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      })
      .reduce((acc, curr) => acc + curr.value, 0);
  }, [state.transactions]);

  const annualIncome = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    return state.transactions
      .filter(t => {
        const d = new Date(t.date);
        return t.type === 'Entrada' && t.status === 'Pago' && d.getFullYear() === currentYear;
      })
      .reduce((acc, curr) => acc + curr.value, 0);
  }, [state.transactions]);

  const monthlyData = useMemo(() => {
    const last6Months = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthLabel = d.toLocaleString('pt-BR', { month: 'short' }).toUpperCase();
      const monthIncome = state.transactions
        .filter(t => {
          const td = new Date(t.date);
          return t.type === 'Entrada' && t.status === 'Pago' && td.getMonth() === d.getMonth() && td.getFullYear() === d.getFullYear();
        })
        .reduce((acc, curr) => acc + curr.value, 0);
      last6Months.push({ label: monthLabel, value: monthIncome });
    }
    return last6Months;
  }, [state.transactions]);

  const criticalTasks = useMemo(() => {
    return state.tasks
      .filter(t => t.status !== 'Concluído')
      .slice(0, 5);
  }, [state.tasks]);

  const pendingPayments = useMemo(() => {
    return state.transactions.filter(t => t.status === 'Pendente' && t.type === 'Saída');
  }, [state.transactions]);

  // Briefing Daily Trigger
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (state.stats.lastBriefingDate !== today) {
      setShowBriefing(true);
    }
  }, [state.stats.lastBriefingDate]);

  useEffect(() => {
    const root = document.documentElement;
    const colors = {
      purple: { primary: '#a855f7', shadow: 'rgba(168, 85, 247, 0.4)' },
      emerald: { primary: '#10b981', shadow: 'rgba(16, 185, 129, 0.4)' },
      cyan: { primary: '#06b6d4', shadow: 'rgba(6, 182, 212, 0.4)' },
      rose: { primary: '#f43f5e', shadow: 'rgba(244, 63, 94, 0.4)' }
    };
    const theme = colors[state.stats.themeColor] || colors.purple;
    root.style.setProperty('--primary-color', theme.primary);
    root.style.setProperty('--primary-shadow', theme.shadow);
  }, [state.stats.themeColor]);

  useEffect(() => {
    localStorage.setItem('cybermanager_state', JSON.stringify(state));
  }, [state]);

  const addXP = useCallback((amount: number) => {
    setState(prev => {
      const newXP = prev.stats.xp + amount;
      const newLevel = Math.floor(newXP / XP_PER_LEVEL) + 1;
      return { ...prev, stats: { ...prev.stats, xp: newXP, level: newLevel } };
    });
  }, []);

  const handleStartDay = (mainGoal: string) => {
    const today = new Date().toISOString().split('T')[0];
    setState(prev => ({
      ...prev,
      stats: {
        ...prev.stats,
        lastBriefingDate: today,
        dailyMainGoal: mainGoal
      }
    }));
    addXP(XP_DAILY_BRIEFING);
    setShowBriefing(false);
  };

  const handleCompleteMainGoal = () => {
    setState(prev => ({
      ...prev,
      stats: { ...prev.stats, dailyMainGoal: prev.stats.dailyMainGoal + ' (Concluída)' }
    }));
    addXP(XP_MAIN_GOAL);
  };

  const addReminder = (text: string) => {
    const type = text.toUpperCase().includes('R$') || text.includes('$') ? 'finance' : 'task';
    const newReminder: Reminder = {
      id: Math.random().toString(36).substr(2, 9),
      text,
      type,
      completed: false
    };
    setState(prev => ({ ...prev, reminders: [newReminder, ...prev.reminders] }));
  };

  const toggleReminder = (id: string) => {
    setState(prev => ({
      ...prev,
      reminders: prev.reminders.map(r => r.id === id ? { ...r, completed: !r.completed } : r)
    }));
  };

  const deleteReminder = (id: string) => {
    setState(prev => ({
      ...prev,
      reminders: prev.reminders.filter(r => r.id !== id)
    }));
  };

  const addClient = useCallback((client: Omit<Client, 'id'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setState(prev => ({ ...prev, clients: [...prev.clients, { ...client, id }] }));
    addXP(XP_PER_CLIENT);
    return id;
  }, [addXP]);

  const addInvoice = useCallback((invoice: Omit<Invoice, 'id'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setState(prev => ({ ...prev, invoices: [...prev.invoices, { ...invoice, id }] }));
    return id;
  }, []);

  const updateInvoice = useCallback((updated: Invoice) => {
    setState(prev => ({ ...prev, invoices: prev.invoices.map(i => i.id === updated.id ? updated : i) }));
  }, []);

  const addTask = useCallback((task: Omit<Task, 'id'>) => {
    const taskId = Math.random().toString(36).substr(2, 9);
    setState(prev => {
      const newState = { ...prev, tasks: [...prev.tasks, { ...task, id: taskId }] };
      if (task.value > 0) {
        newState.transactions.push({
          id: Math.random().toString(36).substr(2, 9),
          description: `Previsto: ${task.title}`,
          value: task.value,
          type: 'Entrada',
          date: new Date().toISOString(),
          status: 'Pendente',
          category: 'Serviço',
          taskId: taskId
        });
      }
      return newState;
    });
  }, []);

  const moveTask = useCallback((taskId: string, day: DayOfWeek) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => t.id === taskId ? { ...t, day } : t)
    }));
  }, []);

  const updateTaskStatus = useCallback((taskId: string, status: Status) => {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;

    if (status === 'Concluído') {
      setPendingPaymentTask(task);
    } else {
      setState(prev => ({
        ...prev,
        tasks: prev.tasks.map(t => t.id === taskId ? { ...t, status } : t)
      }));
    }
  }, [state.tasks]);

  const handleConfirmPayment = (received: boolean) => {
    if (!pendingPaymentTask) return;
    
    setState(prev => {
      const updatedTasks = prev.tasks.map(t => 
        t.id === pendingPaymentTask.id ? { ...t, status: 'Concluído' as Status } : t
      );
      
      const updatedTransactions = prev.transactions.map(tx => {
        if (tx.taskId === pendingPaymentTask.id) {
          return { ...tx, status: (received ? 'Pago' : 'Pendente') as any };
        }
        return tx;
      });

      return { ...prev, tasks: updatedTasks, transactions: updatedTransactions };
    });

    addXP(XP_PER_TASK);
    setPendingPaymentTask(null);
  };

  const handleBudgetApprove = useCallback((budget: Budget, tasks: Omit<Task, 'id'>[], transaction: Omit<Transaction, 'id'>) => {
    const invoiceId = Math.random().toString(36).substr(2, 9);
    const newInvoice: Invoice = {
      id: invoiceId,
      clientId: budget.clientId,
      title: `Orçamento Aprovado: ${new Date().toLocaleDateString()}`,
      createdAt: new Date().toISOString(),
      status: 'Pendente'
    };

    setState(prev => {
      const newTasks = tasks.map(t => ({ ...t, id: Math.random().toString(36).substr(2, 9), invoiceId }));
      const newTransaction = { ...transaction, id: Math.random().toString(36).substr(2, 9) };
      return {
        ...prev,
        budgets: [...prev.budgets, budget],
        invoices: [...prev.invoices, newInvoice],
        tasks: [...prev.tasks, ...newTasks],
        transactions: [...prev.transactions, newTransaction]
      };
    });
    addXP(300);
    setActiveTab('kanban');
  }, [addXP]);

  const updateStats = useCallback((newStats: Partial<UserStats>) => {
    setState(prev => ({ ...prev, stats: { ...prev.stats, ...newStats } }));
  }, []);

  const getClientName = (clientId: string) => state.clients.find(c => c.id === clientId)?.name || 'Cliente Externo';

  const renderContent = () => {
    switch (activeTab) {
      case 'kanban':
        return <KanbanBoard tasks={state.tasks} clients={state.clients} onUpdateStatus={updateTaskStatus} onAddTask={() => setIsTaskModalOpen(true)} onMoveTask={moveTask} />;
      case 'finance':
        return <FinanceDashboard transactions={state.transactions} tasks={state.tasks} weeklyGoal={state.stats.weeklyGoal} onAddTransaction={(tx) => setState(prev => ({ ...prev, transactions: [...prev.transactions, { ...tx, id: Math.random().toString(36).substr(2, 9) }] }))} />;
      case 'clients':
        return <ClientManagement clients={state.clients} onAddClient={addClient} onViewInvoice={setSelectedClientForInvoice} />;
      case 'portfolio':
        return <PortfolioTab albums={state.albums} stats={state.stats} onUpdateAlbums={(albums) => setState(prev => ({...prev, albums}))} onUpdateStats={updateStats} onPreviewPublic={() => setIsPublicView(true)} />;
      case 'budgets':
        return <BudgetBuilder 
          clients={state.clients} 
          services={state.services} 
          stats={state.stats} 
          onApprove={handleBudgetApprove} 
          onQuickAddClient={addClient}
          onSaveCatalog={(s) => setState(prev => ({...prev, services: [...prev.services, {...s, id: Math.random().toString(36).substr(2,9)}]}))} 
        />;
      case 'settings':
        return <SettingsView stats={state.stats} onUpdateStats={updateStats} />;
      case 'dashboard':
      default:
        const monthlyProgress = Math.min((monthlyIncome / (state.stats.monthlyGoal || 1)) * 100, 100);
        const annualProgress = Math.min((annualIncome / (state.stats.annualGoal || 1)) * 100, 100);
        const maxChartValue = Math.max(...monthlyData.map(d => d.value), 1000);

        return (
          <div className="p-4 md:p-8 space-y-8 animate-in fade-in duration-500">
            <h1 className="text-2xl md:text-3xl font-bold cyber-font text-[var(--primary-color)] uppercase">Centro de Comando</h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Stats & Evolution */}
              <div className="lg:col-span-8 space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="bg-slate-900 border border-slate-800 p-6 rounded-[2rem] neon-shadow-primary transition-all hover:border-[var(--primary-color)]/30 group">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 bg-[var(--primary-color)]/20 rounded-xl transition-colors group-hover:bg-[var(--primary-color)]/30"><Award className="text-[var(--primary-color)]" size={24} /></div>
                        <div><p className="text-slate-400 text-xs">Nível Atual</p><p className="text-xl font-bold">Protocolo {state.stats.level}</p></div>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-[var(--primary-color)] h-full transition-all duration-500" style={{ width: `${(state.stats.xp % XP_PER_LEVEL) / (XP_PER_LEVEL / 100)}%` }}></div>
                      </div>
                      <p className="text-[9px] text-slate-500 mt-2 font-black uppercase tracking-widest">XP: {state.stats.xp % XP_PER_LEVEL} / {XP_PER_LEVEL}</p>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-6 rounded-[2rem] transition-all hover:border-emerald-500/30 group">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 bg-emerald-500/20 rounded-xl transition-colors group-hover:bg-emerald-500/30"><TrendingUp className="text-emerald-400" size={24} /></div>
                        <div><p className="text-slate-400 text-xs">Renda Mensal</p><p className="text-xl font-bold">R$ {monthlyIncome.toLocaleString('pt-BR')}</p></div>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full transition-all duration-500" style={{ width: `${monthlyProgress}%` }}></div>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest">Performance</p>
                        <p className="text-[9px] text-emerald-500 font-black">{Math.round(monthlyProgress)}%</p>
                      </div>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-6 rounded-[2rem] transition-all hover:border-blue-500/30 group">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 bg-blue-500/20 rounded-xl transition-colors group-hover:bg-blue-500/30"><Target className="text-blue-400" size={24} /></div>
                        <div><p className="text-slate-400 text-xs">Anual</p><p className="text-xl font-bold">R$ {annualIncome.toLocaleString('pt-BR')}</p></div>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-blue-500 h-full transition-all duration-500" style={{ width: `${annualProgress}%` }}></div>
                      </div>
                      <p className="text-[9px] text-slate-500 mt-2 font-black uppercase tracking-widest">Meta: R$ {state.stats.annualGoal?.toLocaleString()}</p>
                  </div>
                </div>

                {/* Mapeamento Mensal */}
                <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] space-y-8 transition-all hover:border-[var(--primary-color)]/20">
                  <div className="flex items-center justify-between">
                      <h3 className="text-xs font-black text-slate-300 uppercase tracking-widest flex items-center gap-2">
                        <BarChart3 size={18} className="text-[var(--primary-color)]" />
                        Fluxo Operacional
                      </h3>
                      <div className="flex items-center gap-4 text-[9px] font-black text-slate-500 uppercase">
                        <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-[var(--primary-color)]" /> Realizado</span>
                      </div>
                  </div>
                  
                  <div className="h-64 flex items-end justify-between gap-4 px-2">
                      {monthlyData.map((data, idx) => (
                        <div key={idx} className="flex-1 flex flex-col items-center gap-4 group">
                          <div className="relative w-full flex flex-col items-center justify-end h-full">
                            <div className="absolute -top-8 bg-slate-800 text-[9px] font-black px-2 py-1 rounded border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity z-10 text-white whitespace-nowrap shadow-xl">
                              R$ {data.value.toLocaleString()}
                            </div>
                            <div 
                              className="w-full sm:w-12 bg-gradient-to-t from-[var(--primary-color)]/20 to-[var(--primary-color)] rounded-t-xl transition-all duration-700 group-hover:brightness-125 cursor-default relative overflow-hidden"
                              style={{ height: `${(data.value / maxChartValue) * 100}%`, minHeight: '4px' }}
                            >
                              <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-20 transition-opacity" />
                            </div>
                          </div>
                          <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest group-hover:text-slate-300 transition-colors">
                            {data.label}
                          </span>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Demandas Próximas */}
                <div className="bg-slate-900/40 border border-slate-800 rounded-[2.5rem] overflow-hidden flex flex-col transition-all hover:border-slate-700">
                  <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
                    <h3 className="text-xs font-black text-slate-300 uppercase tracking-widest flex items-center gap-2">
                      <Clock size={16} className="text-[var(--primary-color)]" />
                      Protocolos Pendentes
                    </h3>
                    <button onClick={() => setActiveTab('kanban')} className="text-[9px] font-black text-slate-500 hover:text-[var(--primary-color)] transition-colors flex items-center gap-1 uppercase tracking-widest">
                      Expandir Agenda <ChevronRight size={12} />
                    </button>
                  </div>
                  <div className="p-2 divide-y divide-slate-800/50">
                    {criticalTasks.length > 0 ? criticalTasks.map(task => (
                      <div key={task.id} className="p-4 hover:bg-slate-800/40 rounded-2xl transition-all flex items-center justify-between group">
                        <div className="flex flex-col gap-1 overflow-hidden">
                          <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest truncate">
                            {getClientName(task.clientId)}
                          </span>
                          <span className="text-sm font-bold text-slate-200 group-hover:text-white truncate">
                            {task.title}
                          </span>
                        </div>
                        <div className="text-right shrink-0 ml-4">
                          <p className="text-xs font-black text-emerald-400">R$ {task.value.toLocaleString('pt-BR')}</p>
                          <p className={`text-[8px] font-bold uppercase px-1.5 py-0.5 rounded mt-1 inline-block ${task.status === 'Em Andamento' ? 'bg-blue-500/20 text-blue-400' : 'bg-slate-800 text-slate-500'}`}>
                            {task.status}
                          </p>
                        </div>
                      </div>
                    )) : (
                      <div className="p-12 text-center text-slate-600 text-xs italic">Nenhuma demanda pendente no momento.</div>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column: Protocolo Focus */}
              <div className="lg:col-span-4 space-y-8">
                 <FocusWidget 
                    mainGoal={state.stats.dailyMainGoal || ''}
                    reminders={state.reminders}
                    onAddReminder={addReminder}
                    onToggleReminder={toggleReminder}
                    onDeleteReminder={deleteReminder}
                    onCompleteMainGoal={handleCompleteMainGoal}
                    isMainGoalDone={state.stats.dailyMainGoal?.includes('(Concluída)') || false}
                 />

                 {state.stats.objectives && (
                    <div className="bg-slate-900/30 border border-slate-800 p-8 rounded-[2.5rem] relative overflow-hidden group">
                      <div className="absolute top-0 left-0 w-1 h-full bg-[var(--primary-color)] shadow-[0_0_10px_var(--primary-color)]" />
                      <h3 className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-4">Diretrizes Master</h3>
                      <p className="text-slate-300 text-xs leading-relaxed italic">"{state.stats.objectives}"</p>
                    </div>
                 )}
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-50">
      <aside className={`fixed inset-y-0 left-0 z-50 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} lg:relative lg:translate-x-0 lg:flex ${isSidebarOpen ? 'w-64' : 'w-20'} bg-slate-900 border-r border-slate-800 transition-all duration-300 flex flex-col print:hidden`}>
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-[var(--primary-color)] rounded-lg flex items-center justify-center neon-shadow-primary shrink-0 transition-colors">
              <LayoutDashboard size={18} className="text-white" />
            </div>
            {isSidebarOpen && <span className="font-bold text-lg cyber-font tracking-tighter text-white uppercase">NEXUS<span className="text-[var(--primary-color)]">OS</span></span>}
          </div>
          {isMobileMenuOpen && <button onClick={() => setIsMobileMenuOpen(false)} className="lg:hidden text-slate-500 hover:text-white"><X size={20} /></button>}
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <NavItem icon={<LayoutDashboard size={20} />} label="Dashboard" active={activeTab === 'dashboard'} collapsed={!isSidebarOpen} onClick={() => setActiveTab('dashboard')} />
          <NavItem icon={<Calculator size={20} />} label="Propostas" active={activeTab === 'budgets'} collapsed={!isSidebarOpen} onClick={() => setActiveTab('budgets')} />
          <NavItem icon={<Trophy size={20} />} label="Agenda" active={activeTab === 'kanban'} collapsed={!isSidebarOpen} onClick={() => setActiveTab('kanban')} />
          <NavItem icon={<DollarSign size={20} />} label="Fluxo" active={activeTab === 'finance'} collapsed={!isSidebarOpen} onClick={() => setActiveTab('finance')} />
          <NavItem icon={<Users size={20} />} label="Nexus CRM" active={activeTab === 'clients'} collapsed={!isSidebarOpen} onClick={() => setActiveTab('clients')} />
          <NavItem icon={<Briefcase size={20} />} label="Portfólio" active={activeTab === 'portfolio'} collapsed={!isSidebarOpen} onClick={() => setActiveTab('portfolio')} />
          <NavItem icon={<Settings size={20} />} label="Protocolos" active={activeTab === 'settings'} collapsed={!isSidebarOpen} onClick={() => setActiveTab('settings')} />
        </nav>

        <div className="p-4 hidden lg:block">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="w-full flex items-center justify-center p-2 rounded-xl bg-slate-800/50 hover:bg-slate-800 text-slate-400 hover:text-white transition-all">
            <Menu size={20} />
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden w-full">
        <header className="lg:hidden h-14 bg-slate-900 border-b border-slate-800 flex items-center px-4 shrink-0">
          <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 text-slate-400 hover:text-white"><Menu size={24} /></button>
          <span className="ml-4 font-bold cyber-font text-sm uppercase tracking-widest text-[var(--primary-color)]">NEXUS OS</span>
        </header>

        {!isPublicView && <GamificationBar stats={state.stats} currentIncome={monthlyIncome} />}
        
        <div className="flex-1 overflow-auto custom-scrollbar">
          {renderContent()}
        </div>
      </main>

      {/* Modals & Overlays */}
      {showBriefing && (
        <BriefingModal 
          userName={state.stats.name || 'Agente'} 
          criticalTasks={criticalTasks}
          pendingTransactions={pendingPayments}
          onStart={handleStartDay}
        />
      )}
      {isTaskModalOpen && <TaskModal 
        clients={state.clients} 
        invoices={state.invoices} 
        onClose={() => setIsTaskModalOpen(false)} 
        onSubmit={addTask} 
        onQuickAddClient={addClient} 
        onQuickAddInvoice={addInvoice} 
      />}
      {pendingPaymentTask && <PaymentModal task={pendingPaymentTask} onConfirm={handleConfirmPayment} onClose={() => setPendingPaymentTask(null)} />}
      {selectedClientForInvoice && <ProjectNoteModal 
        client={selectedClientForInvoice} 
        tasks={state.tasks.filter(t => t.clientId === selectedClientForInvoice.id)} 
        invoices={state.invoices} 
        pixKey={state.stats.pixKey || ''} 
        onUpdateInvoice={updateInvoice} 
        onUpdatePix={(pix) => updateStats({ pixKey: pix })} 
        onClose={() => setSelectedClientForInvoice(null)} 
      />}
    </div>
  );
};

const NavItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; collapsed?: boolean; onClick: () => void; }> = ({ icon, label, active, collapsed, onClick }) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all ${active ? 'bg-[var(--primary-color)]/15 text-[var(--primary-color)] border border-[var(--primary-color)]/20 shadow-[0_0_10px_var(--primary-shadow)]' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'}`}>
    <div className="shrink-0">{icon}</div>
    {!collapsed && <span className="font-bold text-xs whitespace-nowrap uppercase tracking-[0.1em]">{label}</span>}
  </button>
);

export default App;
