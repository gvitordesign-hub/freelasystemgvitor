
import React from 'react';
import { Target, Flame, DollarSign } from 'lucide-react';
import { UserStats } from '../types';

interface GamificationBarProps {
  stats: UserStats;
  currentIncome: number;
}

const GamificationBar: React.FC<GamificationBarProps> = ({ stats, currentIncome }) => {
  const goal = stats.weeklyGoal || 2000;
  const progressPercentage = Math.min((currentIncome / goal) * 100, 100);

  return (
    <div className="h-16 border-b border-slate-800 bg-slate-900/60 backdrop-blur-md px-4 md:px-6 flex items-center justify-between sticky top-0 z-30 w-full shrink-0">
      <div className="flex items-center gap-3 md:gap-6 flex-1 max-w-2xl">
        <div className="flex items-center gap-2">
          <div className="relative">
            <div className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-[var(--primary-color)] flex items-center justify-center neon-shadow-primary border-2 border-white/10 transition-colors shrink-0">
               <span className="font-bold cyber-font text-white text-sm md:text-base">{stats.level}</span>
            </div>
          </div>
          <div className="hidden sm:block">
            <p className="text-[10px] uppercase tracking-widest text-slate-500 font-black">Progresso</p>
            <p className="text-[10px] md:text-xs font-bold text-[var(--primary-color)] transition-colors">Semana Ativa</p>
          </div>
        </div>

        <div className="flex-1 flex flex-col gap-1">
          <div className="h-1.5 md:h-2 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-[var(--primary-color)] transition-all duration-1000 ease-out shadow-[0_0_10px_var(--primary-color)]"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <div className="flex justify-between text-[8px] md:text-[10px] text-slate-500 font-bold uppercase tracking-tight">
            <span className="text-slate-300">R$ {currentIncome.toLocaleString('pt-BR')}</span>
            <span className="hidden xs:inline">Meta: R$ {goal.toLocaleString('pt-BR')}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 md:gap-4 ml-4">
        <div className="hidden xs:flex items-center gap-1.5 md:gap-2 px-2 md:px-3 py-1 md:py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20">
          <Flame size={12} className="text-amber-500" />
          <span className="text-[10px] md:text-xs font-black text-amber-500 uppercase tracking-tighter">{stats.streak}D</span>
        </div>
        <div className="flex items-center gap-1.5 md:gap-2 px-2 md:px-3 py-1 md:py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
          <DollarSign size={12} className="text-emerald-400" />
          <span className="text-[10px] md:text-xs font-black text-emerald-400 uppercase tracking-tighter sm:inline hidden">Online</span>
          <span className="text-[10px] md:text-xs font-black text-emerald-400 uppercase tracking-tighter sm:hidden inline">R$</span>
        </div>
      </div>
    </div>
  );
};

export default GamificationBar;
