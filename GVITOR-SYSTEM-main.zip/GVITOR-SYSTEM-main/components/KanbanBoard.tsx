
import React, { useState, useMemo } from 'react';
import { 
  Plus, GripVertical, CheckCircle2, Circle, 
  Clock, DollarSign, Calendar as CalendarIcon, 
  LayoutDashboard, List, ChevronLeft, ChevronRight, 
  Briefcase, AlertTriangle, Calendar
} from 'lucide-react';
import { Task, Client, DayOfWeek, Status } from '../types';
import { DAYS_OF_WEEK } from '../constants';

interface KanbanBoardProps {
  tasks: Task[];
  clients: Client[];
  onUpdateStatus: (taskId: string, status: Status) => void;
  onAddTask: () => void;
  onMoveTask: (taskId: string, day: DayOfWeek, date?: string) => void;
}

type ViewMode = 'kanban' | 'diario' | 'mensal';
type DeadlineLevel = 'critical' | 'moderate' | 'light';

const KanbanBoard: React.FC<KanbanBoardProps> = ({ tasks, clients, onUpdateStatus, onAddTask, onMoveTask }) => {
  const [viewMode, setViewMode] = useState<ViewMode>('kanban');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);

  const getClientName = (clientId: string) => clients.find(c => c.id === clientId)?.name || 'Nexus Unknown';

  const onDragStart = (e: React.DragEvent, taskId: string) => {
    setDraggedTaskId(taskId);
    e.dataTransfer.setData('taskId', taskId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const onDragEnd = () => {
    setDraggedTaskId(null);
  };

  const onDrop = (e: React.DragEvent, day: DayOfWeek) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('taskId');
    if (taskId) {
      onMoveTask(taskId, day);
    }
  };

  // Lógica de Hierarquia de Prazos
  const getDeadlineLevel = (taskDateStr: string, status: Status): DeadlineLevel => {
    if (status === 'Concluído') return 'light';
    const taskDate = new Date(taskDateStr);
    const now = new Date();
    const diff = taskDate.getTime() - now.getTime();
    
    if (diff <= 86400000) return 'critical'; // < 24h
    if (diff <= 259200000) return 'moderate'; // 1-3 dias (72h)
    return 'light'; // > 3 dias
  };

  const getDeadlineStyles = (level: DeadlineLevel, isDone: boolean) => {
    if (isDone) return {
      card: 'border-emerald-500/30 bg-emerald-500/5',
      badge: 'bg-emerald-500/10 text-emerald-500',
      text: 'text-slate-500 line-through',
      icon: <CheckCircle2 size={10} />,
      label: 'CONCLUÍDO'
    };

    switch (level) {
      case 'critical':
        return {
          card: 'border-amber-500/60 bg-amber-500/5 shadow-[0_0_20px_rgba(245,158,11,0.1)] ring-1 ring-amber-500/20 animate-pulse-subtle',
          badge: 'bg-amber-500 text-black',
          text: 'text-amber-100',
          icon: <AlertTriangle size={10} />,
          label: 'CRÍTICO'
        };
      case 'moderate':
        return {
          card: 'border-cyan-500/40 bg-cyan-500/5 shadow-[0_0_15px_rgba(6,182,212,0.05)]',
          badge: 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30',
          text: 'text-cyan-50',
          icon: <Clock size={10} />,
          label: 'EM FOCO'
        };
      default:
        return {
          card: 'border-slate-800 bg-slate-900/50 hover:border-[var(--primary-color)]/50',
          badge: 'bg-slate-800 text-slate-500 border border-slate-700',
          text: 'text-slate-200',
          icon: <Calendar size={10} />,
          label: 'PLANEJADO'
        };
    }
  };

  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const nextDay = () => setCurrentDate(new Date(currentDate.getTime() + 86400000));
  const prevDay = () => setCurrentDate(new Date(currentDate.getTime() - 86400000));

  const renderMonthlyView = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const offset = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;
    const days = [];
    for (let i = 0; i < offset; i++) days.push(null);
    for (let i = 1; i <= daysInMonth; i++) days.push(new Date(year, month, i));
    const monthName = currentDate.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });

    return (
      <div className="flex flex-col h-full animate-in fade-in duration-500">
        <div className="flex items-center justify-between mb-4 bg-slate-900/50 p-4 rounded-2xl border border-slate-800">
          <h2 className="cyber-font font-bold text-white uppercase tracking-widest">{monthName}</h2>
          <div className="flex gap-2">
            <button onClick={prevMonth} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400"><ChevronLeft size={20} /></button>
            <button onClick={() => setCurrentDate(new Date())} className="px-4 py-2 hover:bg-slate-800 rounded-lg text-xs font-bold uppercase text-slate-400">Hoje</button>
            <button onClick={nextMonth} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400"><ChevronRight size={20} /></button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1 md:gap-2 flex-1">
          {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'].map(d => (
            <div key={d} className="text-center text-[10px] font-black text-slate-600 uppercase py-2">{d}</div>
          ))}
          {days.map((date, idx) => {
            const dateStr = date?.toISOString().split('T')[0];
            const dayTasks = tasks.filter(t => t.date?.split('T')[0] === dateStr);
            const isToday = date?.toDateString() === new Date().toDateString();

            return (
              <div 
                key={idx} 
                className={`min-h-[80px] md:min-h-[120px] p-2 rounded-xl border border-slate-800/50 flex flex-col gap-1 transition-all ${date ? 'bg-slate-900/20 hover:bg-slate-900/40' : 'opacity-0'} ${isToday ? 'border-[var(--primary-color)]/50 bg-[var(--primary-color)]/5' : ''}`}
              >
                {date && (
                  <>
                    <span className={`text-[10px] font-bold ${isToday ? 'text-[var(--primary-color)]' : 'text-slate-500'}`}>{date.getDate()}</span>
                    <div className="flex-1 overflow-y-auto space-y-1 custom-scrollbar pr-1">
                      {dayTasks.map(t => {
                        const level = getDeadlineLevel(t.date, t.status);
                        const styles = getDeadlineStyles(level, t.status === 'Concluído');
                        return (
                          <div key={t.id} className={`text-[8px] md:text-[9px] p-1 rounded border-l-2 truncate font-medium ${styles.card} ${styles.text}`}>
                            {t.title}
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderDailyView = () => {
    const dateStr = currentDate.toISOString().split('T')[0];
    const dayTasks = tasks.filter(t => t.date?.split('T')[0] === dateStr);
    const dayName = currentDate.toLocaleString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });

    return (
      <div className="flex flex-col h-full max-w-2xl mx-auto w-full animate-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center justify-between mb-6 bg-slate-900/50 p-4 rounded-3xl border border-slate-800">
          <button onClick={prevDay} className="p-2 hover:bg-slate-800 rounded-full text-slate-400"><ChevronLeft size={20} /></button>
          <div className="text-center">
            <h2 className="cyber-font font-bold text-white uppercase text-sm">{dayName}</h2>
          </div>
          <button onClick={nextDay} className="p-2 hover:bg-slate-800 rounded-full text-slate-400"><ChevronRight size={20} /></button>
        </div>

        <div className="space-y-4 flex-1">
          {dayTasks.length > 0 ? dayTasks.map(task => {
            const level = getDeadlineLevel(task.date, task.status);
            const styles = getDeadlineStyles(level, task.status === 'Concluído');
            return (
              <div key={task.id} className={`bg-slate-900 border p-6 rounded-3xl flex items-center justify-between group transition-all ${styles.card}`}>
                <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black uppercase text-[var(--primary-color)] tracking-widest">{getClientName(task.clientId)}</span>
                      <span className={`text-[8px] font-black px-1.5 py-0.5 rounded flex items-center gap-1 ${styles.badge}`}>
                        {styles.icon} {styles.label}
                      </span>
                    </div>
                    <h4 className={`text-lg font-bold ${styles.text}`}>{task.title}</h4>
                    <div className="flex gap-2">
                      <span className="text-[10px] bg-slate-800 px-2 py-1 rounded-md text-slate-400 border border-slate-700 font-bold uppercase tracking-tighter">{task.category}</span>
                      <span className="text-[10px] bg-emerald-500/10 px-2 py-1 rounded-md text-emerald-400 border border-emerald-500/20 font-bold">R$ {task.value.toLocaleString('pt-BR')}</span>
                    </div>
                </div>
                <div className="flex gap-2">
                    <button onClick={() => onUpdateStatus(task.id, 'Concluído')} className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-500 hover:bg-emerald-500 hover:text-white transition-all">
                      <CheckCircle2 size={24} />
                    </button>
                </div>
              </div>
            );
          }) : (
            <div className="py-20 text-center flex flex-col items-center gap-4 opacity-40">
               <Clock size={48} className="text-slate-600" />
               <p className="cyber-font uppercase text-xs font-bold tracking-widest">Protocolo Vazio para Hoje</p>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="p-4 md:p-6 h-full flex flex-col">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6 md:mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold cyber-font text-white uppercase">Agenda de Missões</h1>
          <div className="flex gap-2 mt-4 overflow-x-auto pb-2 no-scrollbar">
            <button 
              onClick={() => setViewMode('kanban')} 
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'kanban' ? 'bg-[var(--primary-color)] text-white neon-shadow-primary' : 'bg-slate-900 text-slate-500 border border-slate-800 hover:text-slate-300'}`}
            >
              <LayoutDashboard size={14} /> Kanban Semanal
            </button>
            <button 
              onClick={() => setViewMode('mensal')} 
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'mensal' ? 'bg-[var(--primary-color)] text-white neon-shadow-primary' : 'bg-slate-900 text-slate-500 border border-slate-800 hover:text-slate-300'}`}
            >
              <CalendarIcon size={14} /> Mensal
            </button>
            <button 
              onClick={() => setViewMode('diario')} 
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'diario' ? 'bg-[var(--primary-color)] text-white neon-shadow-primary' : 'bg-slate-900 text-slate-500 border border-slate-800 hover:text-slate-300'}`}
            >
              <List size={14} /> Diário
            </button>
          </div>
        </div>
        <button 
          onClick={onAddTask}
          className="flex items-center justify-center gap-2 bg-[var(--primary-color)] hover:brightness-110 text-white px-6 py-4 rounded-2xl font-black transition-all neon-shadow-primary text-xs uppercase tracking-widest shrink-0"
        >
          <Plus size={18} />
          Adicionar Demanda
        </button>
      </div>

      <div className="flex-1 overflow-hidden">
        {viewMode === 'kanban' && (
          <div className="h-full flex gap-4 overflow-x-auto pb-6 snap-x snap-mandatory">
            {DAYS_OF_WEEK.map(day => (
              <div 
                key={day} 
                className="flex-shrink-0 w-[85vw] sm:w-80 bg-slate-900/40 border border-slate-800 rounded-3xl flex flex-col snap-center"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => onDrop(e, day)}
              >
                <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60 rounded-t-3xl">
                  <h3 className="font-bold cyber-font text-slate-300 uppercase tracking-widest text-[10px]">{day}</h3>
                  <span className="bg-slate-800 text-slate-500 text-[10px] px-2 py-0.5 rounded-lg border border-slate-700 font-bold">
                    {tasks.filter(t => t.day === day).length}
                  </span>
                </div>
                
                <div className="flex-1 p-3 space-y-3 overflow-y-auto min-h-[400px] md:min-h-[500px] custom-scrollbar">
                  {tasks.filter(t => t.day === day).map(task => {
                    const level = getDeadlineLevel(task.date, task.status);
                    const styles = getDeadlineStyles(level, task.status === 'Concluído');
                    const isDragged = draggedTaskId === task.id;
                    return (
                      <div 
                        key={task.id}
                        draggable
                        onDragStart={(e) => onDragStart(e, task.id)}
                        onDragEnd={onDragEnd}
                        className={`group border p-4 rounded-2xl transition-all cursor-grab active:cursor-grabbing ${isDragged ? 'opacity-40 grayscale scale-95' : ''} ${styles.card}`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex flex-col gap-1">
                            <span className="text-[8px] font-black uppercase tracking-widest text-slate-500 bg-slate-950 px-2 py-1 rounded-md border border-slate-800 max-w-[150px] truncate">
                              {getClientName(task.clientId)}
                            </span>
                            <div className={`flex items-center gap-1 text-[7px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded ${styles.badge}`}>
                              {styles.icon} {styles.label}
                            </div>
                          </div>
                          <div className={`text-slate-700 group-hover:text-[var(--primary-color)] transition-colors`}>
                            <GripVertical size={14} />
                          </div>
                        </div>

                        <h4 className={`font-bold text-sm mb-4 leading-snug transition-all ${styles.text}`}>
                          {task.title}
                        </h4>

                        <div className="flex items-center justify-between mt-auto pt-3 border-t border-slate-800/50">
                          <div className="flex flex-col">
                            <div className={`flex items-center gap-1 font-black text-xs ${task.status === 'Concluído' ? 'text-slate-600' : 'text-emerald-400'}`}>
                              <DollarSign size={12} />
                              {task.value.toLocaleString('pt-BR')}
                            </div>
                            {task.status === 'Concluído' && (
                              <div className="flex items-center gap-1 text-purple-400 text-[8px] font-bold uppercase mt-1">
                                 <Briefcase size={8} /> Portfólio
                              </div>
                            )}
                          </div>

                          <div className="flex gap-1">
                            <button 
                              onClick={() => onUpdateStatus(task.id, 'Em Andamento')}
                              className={`p-1.5 rounded-lg transition-colors ${task.status === 'Em Andamento' ? 'bg-blue-500/20 text-blue-400' : 'text-slate-600 hover:text-slate-400'}`}
                            >
                              <Circle size={14} />
                            </button>
                            <button 
                              onClick={() => onUpdateStatus(task.id, 'Concluído')}
                              className={`p-1.5 rounded-lg transition-colors ${task.status === 'Concluído' ? 'bg-emerald-500 text-slate-950 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 'text-slate-600 hover:text-slate-400'}`}
                            >
                              <CheckCircle2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  
                  {tasks.filter(t => t.day === day).length === 0 && (
                    <div className="h-32 border-2 border-dashed border-slate-800/50 rounded-2xl flex items-center justify-center text-slate-700 text-[10px] font-bold uppercase tracking-widest italic opacity-40">
                      Agenda Vazia
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
        {viewMode === 'mensal' && renderMonthlyView()}
        {viewMode === 'diario' && renderDailyView()}
      </div>
    </div>
  );
};

export default KanbanBoard;
