
import React, { useState } from 'react';
import { Wallet, TrendingUp, TrendingDown, Clock, Search, Plus, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Transaction, Task, TransactionType } from '../types';

interface FinanceDashboardProps {
  transactions: Transaction[];
  tasks: Task[];
  weeklyGoal: number;
  onAddTransaction: (tx: Omit<Transaction, 'id'>) => void;
}

const FinanceDashboard: React.FC<FinanceDashboardProps> = ({ transactions, tasks, weeklyGoal, onAddTransaction }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    description: '',
    value: '',
    type: 'Saída' as TransactionType,
    category: 'Geral'
  });

  const totalBalance = transactions
    .filter(t => t.status === 'Pago')
    .reduce((acc, curr) => curr.type === 'Entrada' ? acc + curr.value : acc - curr.value, 0);

  const realIncome = transactions
    .filter(t => t.type === 'Entrada' && t.status === 'Pago')
    .reduce((acc, curr) => acc + curr.value, 0);

  const pendingIncome = transactions
    .filter(t => t.type === 'Entrada' && t.status === 'Pendente')
    .reduce((acc, curr) => acc + curr.value, 0);

  const totalExpenses = transactions
    .filter(t => t.type === 'Saída')
    .reduce((acc, curr) => acc + curr.value, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddTransaction({
      description: formData.description,
      value: parseFloat(formData.value),
      type: formData.type,
      date: new Date().toISOString(),
      status: 'Pago',
      category: formData.category
    });
    setFormData({ description: '', value: '', type: 'Saída', category: 'Geral' });
    setShowAddForm(false);
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold cyber-font text-white uppercase tracking-tighter">Fluxo de Caixa</h1>
          <p className="text-slate-400">Controle total sobre o seu capital</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-lg flex items-center gap-2"
        >
          <Plus size={20} />
          {showAddForm ? 'Cancelar' : 'Novo Lançamento'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-purple-500/20 rounded-xl">
              <Wallet className="text-purple-400" />
            </div>
          </div>
          <p className="text-slate-400 text-sm font-medium">Saldo Atual</p>
          <h2 className="text-3xl font-bold mt-1">R$ {totalBalance.toLocaleString()}</h2>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-emerald-500/20 rounded-xl">
              <TrendingUp className="text-emerald-400" />
            </div>
            <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded">REALIZADO</span>
          </div>
          <p className="text-slate-400 text-sm font-medium">Entradas</p>
          <h2 className="text-3xl font-bold mt-1 neon-text-green">R$ {realIncome.toLocaleString()}</h2>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-amber-500/20 rounded-xl">
              <Clock className="text-amber-400" />
            </div>
            <span className="text-[10px] font-bold text-amber-500 bg-amber-500/10 px-2 py-1 rounded">PREVISTO</span>
          </div>
          <p className="text-slate-400 text-sm font-medium">Previsão</p>
          <h2 className="text-3xl font-bold mt-1 text-amber-400">R$ {pendingIncome.toLocaleString()}</h2>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-rose-500/20 rounded-xl">
              <TrendingDown className="text-rose-400" />
            </div>
          </div>
          <p className="text-slate-400 text-sm font-medium">Saídas</p>
          <h2 className="text-3xl font-bold mt-1 neon-text-red">R$ {totalExpenses.toLocaleString()}</h2>
        </div>
      </div>

      {showAddForm && (
        <form onSubmit={handleSubmit} className="mb-8 bg-slate-900 border border-emerald-500/30 p-6 rounded-2xl grid grid-cols-1 md:grid-cols-5 gap-4 items-end animate-in fade-in duration-300">
          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">Descrição</label>
            <input 
              required
              type="text" 
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              placeholder="Ex: Aluguel, Internet..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">Valor (R$)</label>
            <input 
              required
              type="number" 
              value={formData.value}
              onChange={e => setFormData({...formData, value: e.target.value})}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">Tipo</label>
            <select 
              value={formData.type}
              onChange={e => setFormData({...formData, type: e.target.value as TransactionType})}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:outline-none focus:border-emerald-500 transition-colors"
            >
              <option value="Saída">Saída</option>
              <option value="Entrada">Entrada</option>
            </select>
          </div>
          <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-lg transition-all">
            Salvar
          </button>
        </form>
      )}

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/60">
          <h3 className="font-bold cyber-font">Histórico de Transações</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
            <input 
              type="text" 
              placeholder="Buscar..." 
              className="bg-slate-800 border border-slate-700 rounded-full pl-10 pr-4 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-purple-500"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] text-slate-500 uppercase tracking-widest font-bold border-b border-slate-800">
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Descrição</th>
                <th className="px-6 py-4">Categoria</th>
                <th className="px-6 py-4 text-right">Valor</th>
                <th className="px-6 py-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(tx => (
                <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors group">
                  <td className="px-6 py-4 text-sm text-slate-400 font-mono">
                    {new Date(tx.date).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-slate-200">
                    <div className="flex items-center gap-3">
                      <div className={`p-1.5 rounded-md ${tx.type === 'Entrada' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                        {tx.type === 'Entrada' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                      </div>
                      {tx.description}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-xs">
                    <span className="bg-slate-800 text-slate-400 px-2 py-1 rounded">{tx.category}</span>
                  </td>
                  <td className={`px-6 py-4 text-sm font-bold text-right ${tx.type === 'Entrada' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {tx.type === 'Entrada' ? '+' : '-'} R$ {tx.value.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase ${tx.status === 'Pago' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-500'}`}>
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))}
              {transactions.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-500">
                    Nenhuma transação registrada.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FinanceDashboard;
