
import React, { useState } from 'react';
import { Target, Zap, DollarSign, ListTodo, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';
import { Task, Transaction } from '../../types';

interface BriefingModalProps {
  userName: string;
  criticalTasks: Task[];
  pendingTransactions: Transaction[];
  onStart: (mainGoal: string) => void;
}

const BriefingModal: React.FC<BriefingModalProps> = ({ userName, criticalTasks, pendingTransactions, onStart }) => {
  const [goal, setGoal] = useState('');

  const totalPending = pendingTransactions.reduce((acc, curr) => acc + curr.value, 0);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-2xl animate-in fade-in duration-500">
      <div className="bg-slate-900/40 border border-slate-800 w-full max-w-2xl rounded-[3rem] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.5)] animate-in zoom-in-95 duration-500 relative">
        {/* Decorative Grid Background */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(var(--primary-color) 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
        
        <div className="p-10 relative z-10 space-y-8">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
               <div className="w-12 h-1 h-1 bg-[var(--primary-color)] rounded-full animate-pulse" />
               <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em]">Morning Protocol v2.5</span>
            </div>
            <h1 className="text-4xl font-black text-white cyber-font uppercase tracking-tighter">
              Bom dia, {userName.split(' ')[0]}
            </h1>
            <p className="text-slate-400 text-sm">O sistema está operacional. Aqui está o seu panorama de hoje:</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div className="bg-slate-950/50 border border-slate-800 p-5 rounded-3xl flex items-center gap-4 group hover:border-[var(--primary-color)]/30 transition-all">
                <div className="w-12 h-12 bg-[var(--primary-color)]/10 rounded-2xl flex items-center justify-center text-[var(--primary-color)]">
                   <ListTodo size={24} />
                </div>
                <div>
                   <p className="text-lg font-black text-white">{criticalTasks.length}</p>
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Demandas Críticas</p>
                </div>
             </div>

             <div className="bg-slate-950/50 border border-slate-800 p-5 rounded-3xl flex items-center gap-4 group hover:border-emerald-500/30 transition-all">
                <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
                   <DollarSign size={24} />
                </div>
                <div>
                   <p className="text-lg font-black text-white">R$ {totalPending.toLocaleString()}</p>
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Contas Pendentes</p>
                </div>
             </div>
          </div>

          <div className="bg-[var(--primary-color)]/5 border border-[var(--primary-color)]/20 p-8 rounded-[2rem] space-y-4">
             <div className="flex items-center gap-2 text-[10px] font-black text-[var(--primary-color)] uppercase tracking-widest">
                <Target size={14} /> Defina sua Intenção Principal
             </div>
             <input 
               autoFocus
               value={goal}
               onChange={e => setGoal(e.target.value)}
               placeholder="Qual é a sua Meta de Ouro hoje?"
               className="w-full bg-transparent border-none outline-none text-2xl font-bold text-white placeholder:text-slate-700"
             />
             <p className="text-[10px] text-slate-500 italic">"Concluir este objetivo garante +100 XP extras."</p>
          </div>

          <div className="flex items-center justify-between pt-4">
             <div className="flex items-center gap-2 text-[10px] font-black text-emerald-500 uppercase">
                <ShieldCheck size={16} /> Protocolos Ativos
             </div>
             <button 
              onClick={() => onStart(goal)}
              className="bg-white text-slate-950 px-8 py-4 rounded-2xl font-black uppercase text-xs tracking-widest flex items-center gap-3 hover:scale-105 active:scale-95 transition-all shadow-xl"
             >
               Aceitar Missão <ArrowRight size={18} />
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BriefingModal;
