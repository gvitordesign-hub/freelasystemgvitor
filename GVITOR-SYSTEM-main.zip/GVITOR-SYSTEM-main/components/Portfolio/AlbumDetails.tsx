import React, { useState, useRef } from 'react';
import { ChevronLeft, Plus, Image as ImageIcon, Film, Trash2, X, Play, Loader2, Upload, Files } from 'lucide-react';
import { Album, PortfolioAsset } from '../../types';

interface AlbumDetailsProps {
  album: Album;
  onBack: () => void;
  onUpdate: (album: Album) => void;
}

const AlbumDetails: React.FC<AlbumDetailsProps> = ({ album, onBack, onUpdate }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processProgress, setProcessProgress] = useState({ current: 0, total: 0 });
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const processImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          canvas.width = img.width;
          canvas.height = img.height;
          if (ctx) {
            ctx.drawImage(img, 0, 0);
            resolve(canvas.toDataURL('image/webp', 0.8));
          } else reject('Canvas Error');
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleBatchFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    // Fix: Explicitly cast Array.from result to File[] to avoid 'unknown' inference and fix property access errors
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;

    setIsProcessing(true);
    setProcessProgress({ current: 0, total: files.length });
    
    const newAssets: PortfolioAsset[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setProcessProgress(prev => ({ ...prev, current: i + 1 }));
      
      try {
        let url = '';
        let type: 'image' | 'video' = file.type.startsWith('image/') ? 'image' : 'video';
        
        if (type === 'image') {
          url = await processImage(file);
        } else {
          url = await new Promise((res) => {
            const r = new FileReader();
            r.onload = (ev) => res(ev.target?.result as string);
            r.readAsDataURL(file);
          });
        }

        newAssets.push({
          id: Math.random().toString(36).substr(2, 9),
          type,
          url,
          description: ''
        });
      } catch (err) {
        console.error('Falha ao processar arquivo:', file.name);
      }
    }

    onUpdate({ ...album, assets: [...album.assets, ...newAssets] });
    setIsProcessing(false);
    setIsAdding(false);
  };

  return (
    <div className="p-4 md:p-8 space-y-8 animate-in slide-in-from-right-8 duration-500">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-white transition-all text-xs font-black uppercase tracking-widest">
          <ChevronLeft size={16} /> Voltar aos Álbuns
        </button>
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 bg-[var(--primary-color)] hover:brightness-110 text-white px-6 py-3 rounded-2xl font-black transition-all neon-shadow-primary text-xs uppercase tracking-widest"
        >
          <Plus size={18} /> Injetar Mídias
        </button>
      </div>

      <div className="bg-slate-900/50 border border-slate-800 p-8 rounded-3xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--primary-color)]/5 blur-[100px] -z-10" />
        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[var(--primary-color)] mb-2 block">{album.category}</span>
        <h1 className="text-3xl font-bold text-white cyber-font uppercase">{album.title}</h1>
      </div>

      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-3xl p-6 space-y-5 animate-in zoom-in-95">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-white uppercase cyber-font">Upload em Lote</h3>
              <button onClick={() => setIsAdding(false)} className="text-slate-500 hover:text-white"><X size={20} /></button>
            </div>

            <div 
              onClick={() => !isProcessing && fileInputRef.current?.click()}
              className={`relative h-56 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all ${isProcessing ? 'border-amber-500/50 bg-amber-500/5 cursor-wait' : 'border-slate-800 hover:border-[var(--primary-color)]/50 bg-slate-800/20'}`}
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                multiple
                accept="image/*,video/*"
                onChange={handleBatchFileChange}
              />
              
              {isProcessing ? (
                <>
                  <Loader2 className="text-amber-500 animate-spin mb-4" size={40} />
                  <span className="text-sm font-black uppercase text-amber-500 tracking-widest">Processando Mídias</span>
                  <span className="text-[10px] font-bold text-slate-500 mt-2">{processProgress.current} de {processProgress.total} arquivos</span>
                </>
              ) : (
                <>
                  <Files className="text-slate-600 mb-4" size={40} />
                  <span className="text-sm font-bold text-slate-200">Selecione Múltiplos Arquivos</span>
                  <span className="text-[10px] text-slate-500 uppercase mt-2 tracking-tighter">Imagens serão otimizadas para WEBP</span>
                </>
              )}
            </div>

            <button 
              onClick={() => setIsAdding(false)}
              className="w-full bg-slate-800 text-slate-400 font-bold py-3 rounded-xl uppercase text-[10px] tracking-widest"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {album.assets.map(asset => (
          <div key={asset.id} className="group relative aspect-square bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 hover:border-[var(--primary-color)]/50 transition-all">
            {asset.type === 'image' ? (
              <img src={asset.url} alt="" className="w-full h-full object-cover transition-transform group-hover:scale-110" />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-slate-800">
                <Play className="text-[var(--primary-color)] mb-2" size={32} />
                <span className="text-[8px] font-bold text-slate-500 uppercase">Protocolo Vídeo</span>
              </div>
            )}
            <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <button 
                onClick={() => onUpdate({ ...album, assets: album.assets.filter(a => a.id !== asset.id) })}
                className="p-3 bg-rose-500/20 text-rose-500 hover:bg-rose-500 hover:text-white rounded-full transition-all"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AlbumDetails;