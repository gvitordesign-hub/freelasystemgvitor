
import React from 'react';
import { Trash2, ImageIcon, Film } from 'lucide-react';
import { Album } from '../../types';

interface AlbumCardProps {
  album: Album;
  onClick: () => void;
  onDelete: () => void;
}

const AlbumCard: React.FC<AlbumCardProps> = ({ album, onClick, onDelete }) => {
  const imagesCount = album.assets.filter(a => a.type === 'image').length;
  const videosCount = album.assets.filter(a => a.type === 'video').length;

  // Tenta pegar a primeira imagem como capa, senão usa a coverImage padrão
  const firstImageAsset = album.assets.find(a => a.type === 'image');
  const displayCover = firstImageAsset ? firstImageAsset.url : album.coverImage;

  return (
    <div className="group relative bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden hover:border-[var(--primary-color)]/50 transition-all duration-300">
      {/* Thumbnail */}
      <div 
        onClick={onClick}
        className="aspect-[4/3] bg-cover bg-center cursor-pointer transition-transform duration-500 group-hover:scale-105"
        style={{ backgroundImage: `url(${displayCover})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
      </div>

      {/* Content */}
      <div className="absolute bottom-0 left-0 w-full p-5 pointer-events-none">
        <span className="text-[8px] font-black uppercase tracking-[0.2em] text-[var(--primary-color)] bg-[var(--primary-color)]/10 px-2 py-1 rounded border border-[var(--primary-color)]/20 mb-2 inline-block">
          {album.category}
        </span>
        <h3 className="text-white font-bold text-lg leading-tight group-hover:text-[var(--primary-color)] transition-colors">
          {album.title}
        </h3>
        <div className="flex items-center gap-3 mt-2 text-slate-500 text-[10px] font-bold uppercase">
          <span className="flex items-center gap-1"><ImageIcon size={10} /> {imagesCount}</span>
          <span className="flex items-center gap-1"><Film size={10} /> {videosCount}</span>
        </div>
      </div>

      {/* Actions */}
      <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <button 
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          className="p-2 bg-rose-500/20 text-rose-500 hover:bg-rose-500 hover:text-white rounded-xl backdrop-blur-md transition-all"
        >
          <Trash2 size={14} />
        </button>
      </div>
    </div>
  );
};

export default AlbumCard;
