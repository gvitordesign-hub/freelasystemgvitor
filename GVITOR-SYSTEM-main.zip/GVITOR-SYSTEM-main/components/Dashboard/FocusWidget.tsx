
import React, { useState } from 'react';
import { Target, Zap, Plus, Circle, CheckCircle2, DollarSign, Trash2, ArrowRight, Sparkles } from 'lucide-react';
import { Reminder } from '../../types';

interface FocusWidgetProps {
  mainGoal: string;
  reminders: Reminder[];
  onAddReminder: (text: string) => void;
  onToggleReminder: (id: string) => void;
  onDeleteReminder: (id: string) => void;
  onCompleteMainGoal: () => void;
  isMainGoalDone: boolean;
}

const FocusWidget: React.FC<FocusWidgetProps> = ({ 
  mainGoal, 
  reminders, 
  onAddReminder, 
  onToggleReminder, 
  onDeleteReminder,
  onCompleteMainGoal,
  isMainGoalDone
}) => {
  const [inputValue, setInputValue] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    onAddReminder(inputValue);
    setInputValue('');
  };

  return (
    <div className="space-y-6">
      {/* Meta Principal */}
      <div className={`relative overflow-hidden p-6 rounded-[2.5rem] border-2 transition-all duration-500 ${isMainGoalDone ? 'bg-emerald-500/10 border-emerald-500/50 scale-[0.98]' : 'bg-[var(--primary-color)]/5 border-[var(--primary-color)]/20 shadow-xl'}`}>
         {isMainGoalDone && <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_50%_-20%,rgba(16,185,129,0.3),transparent)]" />}
         
         <div className="flex items-center justify-between mb-4 relative z-10">
            <span className={`text-[9px] font-black uppercase tracking-[0.2em] flex items-center gap-2 ${isMainGoalDone ? 'text-emerald-500' : 'text-[var(--primary-color)]'}`}>
              <Target size={14} /> 
              {isMainGoalDone ? 'Missão Cumprida' : 'Protocolo: Meta de Ouro'}
            </span>
            {!isMainGoalDone && (
              <button 
                onClick={onCompleteMainGoal}
                className="bg-white/10 hover:bg-white/20 text-white p-2 rounded-full transition-all"
                title="Concluir Meta Principal"
              >
                <CheckCircle2 size={16} />
              </button>
            )}
         </div>

         <div className="flex items-center gap-4 relative z-10">
            <h2 className={`text-xl md:text-2xl font-bold cyber-font leading-tight ${isMainGoalDone ? 'text-slate-500 line-through' : 'text-white'}`}>
              {mainGoal || 'Nenhuma meta definida para hoje.'}
            </h2>
            {isMainGoalDone && <Sparkles className="text-emerald-400 animate-bounce" size={24} />}
         </div>

         {!isMainGoalDone && mainGoal && (
            <div className="mt-4 flex items-center gap-2 text-[10px] font-bold text-slate-500">
               <Zap size={10} className="text-amber-500" /> +100 XP bônus ao finalizar
            </div>
         )}
      </div>

      {/* Lembretes Rápidos */}
      <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden flex flex-col">
         <div className="p-6 border-b border-slate-800 bg-slate-950/30">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Briefing de Operações</h3>
            <form onSubmit={handleAdd} className="relative">
               <input 
                  value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  placeholder="Novo lembrete (Dica: use R$ para financeiro)"
                  className="w-full bg-slate-800 border border-slate-700 rounded-2xl pl-12 pr-4 py-4 text-xs text-white focus:border-[var(--primary-color)] outline-none transition-all"
               />
               <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600">
                  <Plus size={18} />
               </div>
               <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-[var(--primary-color)]/20 text-[var(--primary-color)] rounded-xl opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowRight size={14} />
               </button>
            </form>
         </div>

         <div className="flex-1 p-4 max-h-[400px] overflow-y-auto custom-scrollbar space-y-2">
            {reminders.map(rem => (
              <div 
                key={rem.id} 
                className={`group flex items-center justify-between p-4 rounded-2xl border transition-all ${rem.completed ? 'bg-slate-950/50 border-transparent opacity-50' : 'bg-slate-800/40 border-slate-800 hover:border-slate-700'}`}
              >
                <div className="flex items-center gap-4">
                   <button 
                    onClick={() => onToggleReminder(rem.id)}
                    className={`transition-colors ${rem.completed ? 'text-emerald-500' : 'text-slate-600 hover:text-white'}`}
                   >
                      {rem.completed ? <CheckCircle2 size={18} /> : <Circle size={18} />}
                   </button>
                   <div className="flex flex-col">
                      <span className={`text-xs font-bold ${rem.completed ? 'line-through text-slate-600' : 'text-slate-200'}`}>
                        {rem.text}
                      </span>
                      {rem.type === 'finance' && (
                        <span className="text-[8px] font-black text-rose-500 uppercase tracking-tighter flex items-center gap-1">
                           <DollarSign size={8} /> Pagamento Crítico
                        </span>
                      )}
                   </div>
                </div>
                <button 
                  onClick={() => onDeleteReminder(rem.id)}
                  className="text-slate-700 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                >
                   <Trash2 size={14} />
                </button>
              </div>
            ))}
            {reminders.length === 0 && (
              <div className="py-12 text-center">
                 <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest italic">Nenhum lembrete operacional</p>
              </div>
            )}
         </div>
      </div>
    </div>
  );
};

export default FocusWidget;
